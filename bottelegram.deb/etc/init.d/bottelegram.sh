#! /bin/bash
set -x
### BEGIN INIT INFO
# Provides:          bottelegram
# Required-Start:    $local_fs $network
# Required-Stop:     $local_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: bottelegram service
# Description:       Run bottelegram service
### END INIT INFO

do_start() {
    echo "Start"
    echo "Starting bottelegram..."
    cd /usr/local/bin/bottelegram/deb_packets
	if ! [ -f ./installed_ok ]; then
		echo "File installed_ok does not exist."
		if [ -f /usr/local/bin/set_root_state.sh ]; then
			/usr/local/bin/set_root_state.sh &
		fi
		dpkg -i *.deb 1>/dev/null 2>/dev/null
		ret=$?
		if [ "$ret" == "0" ]; then
			touch installed_ok
		else
			echo "fail install debs"
		fi
	fi

    cd /usr/local/bin/
    smse -f 1>/dev/null 2>/dev/null &#tg_bot.php 1>/dev/null 2>/dev/null &

    #cd /usr/local/bin/bottelegram
    #php tg_bot.php 1>/dev/null 2>/dev/null &

    if ps aux | grep tg_bot.php | grep -v grep > /dev/null
      then
        echo "Already running"
    else
      echo "Not running, running..."
      cd /usr/local/bin/bottelegram
      php tg_bot.php 1>/dev/null 2>/dev/null &
    fi

    if grep -q "sudo service bottelegram.sh stopclean" /projects/restart.before 
      then echo "String restart exist!"
    else
      echo "Did not find string restart, adding"
      echo  -e "\nsudo service bottelegram.sh stopclean" >> /projects/restart.before 
    fi

    if grep -q "sudo service bottelegram.sh start" /projects/start.after
      then echo "String start exist!"
    else
      echo "Did not find string start, adding"
      echo -e "\nsudo service bottelegram.sh start" >> /projects/start.after
    fi

}

do_stop() {
    echo "Stop"
    echo "Stopping bottelegram..."
    pkill -9 -e -f tg_bot.php
    sleep 1
}

do_clean(){

    echo "Clean Cache"
    echo "Cleaning Cache bottelegram..."
    rm -f /projects/sys/cache_bot/*
    sleep 2


}

# Carry out specific functions when asked to by the system
case "$1" in
  start)
    do_start
    ;;
  stop)
    do_stop
    ;;
  restart)
   do_stop
   do_start
   ;;
  stopclean)
  do_stop
  do_clean
  ;;
  *)
    echo "Usage: /etc/init.d/bottelegram.sh {start|stop|restart|stopclean}"
    exit 1
    ;;
esac

exit 0
